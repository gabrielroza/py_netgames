# py-ringo

## Instalação de dependências

Certifique-se de instalar o pygame com o comando:

`python3 -m pip install -U pygame --user`

## Executar

Na raíz do diretório, executar o comando:

`python3 py-ringo/main.py`

## Documentação

O pdf da especificação de requisitos e o arquivo vpp está em `documentation/`.
