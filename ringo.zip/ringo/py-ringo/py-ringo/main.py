from utils.Controller import Controller

game = Controller()

game.run()
