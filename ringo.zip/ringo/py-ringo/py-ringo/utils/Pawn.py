from utils.Token import Token


class Pawn(Token):
    def __init__(self, color, radius):
        super().__init__(color, radius)
