from utils.Token import Token


class Ring(Token):
    def __init__(self, color, radius):
        super().__init__(color, radius)
